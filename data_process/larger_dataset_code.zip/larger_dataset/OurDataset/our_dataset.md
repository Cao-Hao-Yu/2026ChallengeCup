# 比赛数据集

图像大多为850x850
其中MAR20部分图像均为800x800，仅有少数几张尺寸不对

比赛数据集的标签我后来又改过了，新增了非常多的框，最新的是v2版本的
OurDataset文件夹里面的标签就是最新的

duplicate2obb.py
与其他同名代码几乎相同，需要在relabel之后运行，将hbb标签转换并复制到obb路径下

relabel_class_id.py
类别重映射，与其他同名代码几乎相同，在duplicate之前运行